
export interface EditorState {
  originalImage: string | null;
  currentImage: string | null;
  history: HistoryItem[];
  referenceImages: ReferenceImage[];
  isLoading: boolean;
  error: string | null;
}

export interface HistoryItem {
  id: string;
  imageUrl: string;
  videoUrl?: string;
  prompt: string;
  timestamp: number;
  mode?: EditorMode;
}

export interface ReferenceImage {
  id: string;
  url: string;
}

export interface ProcessedImage {
  imageUrl: string;
  prompt: string;
}

export enum EditorMode {
  UPLOAD = 'UPLOAD',
  EDIT = 'EDIT',
  GENERATE = 'GENERATE',
  ANALYZE = 'ANALYZE',
  TRANSFORM = 'TRANSFORM',
  REMOVE = 'REMOVE',
  COLOR = 'COLOR',
  VIDEO = 'VIDEO',
  STYLE = 'STYLE'
}

export type AspectRatio = '1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '9:16' | '16:9' | '21:9';
export type ImageSize = '1K' | '2K' | '4K';
