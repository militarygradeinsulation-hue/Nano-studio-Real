
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AspectRatio, ImageSize } from "../types";

const API_KEY = process.env.API_KEY || '';

// Initialize the AI client
const ai = new GoogleGenAI({ apiKey: API_KEY });

const MODEL_IMAGE_PRIMARY = 'gemini-3-pro-image-preview'; // Primary: Nano Banana Pro
const MODEL_IMAGE_FALLBACK = 'gemini-2.5-flash-image';   // Fallback: Flash
const MODEL_TEXT = 'gemini-3-pro-preview';               // Text/Analysis

/**
 * Helper to clean base64 string.
 */
export const cleanBase64 = (dataUrl: string): string => {
  const parts = dataUrl.split(',');
  return parts.length > 1 ? parts[1] : parts[0];
};

/**
 * Helper to get mime type from base64 string.
 */
export const getMimeType = (dataUrl: string): string => {
  const match = dataUrl.match(/^data:(image\/[a-zA-Z+]+);base64,/);
  return match ? match[1] : 'image/png';
};

/**
 * Retry helper for API calls
 */
const retryOperation = async <T>(operation: () => Promise<T>, maxRetries: number = 3, delay: number = 2000): Promise<T> => {
  let lastError: any;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      
      // Extract error details
      // The error object from the SDK might wrap the raw response
      const status = error.status || error.response?.status || error.code;
      const message = error.message || '';
      
      const isOverloaded = 
        status === 503 || 
        status === 429 || 
        message.includes('503') || 
        message.includes('overloaded') ||
        message.includes('UNAVAILABLE');

      if (isOverloaded && i < maxRetries - 1) {
        const waitTime = delay * Math.pow(2, i); // Exponential backoff
        console.warn(`Gemini API Overloaded (Attempt ${i + 1}/${maxRetries}). Retrying in ${waitTime}ms...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
        continue;
      }
      
      throw error;
    }
  }
  throw lastError;
};

/**
 * Generates a new image from text with optional reference images and fallback support.
 */
export const generateImageWithGemini = async (
  prompt: string,
  referenceImages: string[] = [],
  aspectRatio: AspectRatio,
  imageSize: ImageSize
): Promise<string> => {
  if (!API_KEY) throw new Error("API Key is missing.");

  const generate = async (model: string, useImageSize: boolean) => {
    const parts: any[] = [];

    // Add references
    for (const ref of referenceImages) {
      parts.push({
        inlineData: {
          data: cleanBase64(ref),
          mimeType: getMimeType(ref),
        }
      });
    }

    // Add prompt
    let finalPrompt = prompt;
    if (referenceImages.length > 0) {
      finalPrompt = `${prompt} (Use the provided images as visual reference)`;
    }
    parts.push({ text: finalPrompt });

    const config: any = {
      imageConfig: {
        aspectRatio: aspectRatio,
      }
    };

    // Only add imageSize if the model supports it (Primary model)
    if (useImageSize) {
      config.imageConfig.imageSize = imageSize;
    }

    const response = await retryOperation<GenerateContentResponse>(() => ai.models.generateContent({
      model: model,
      contents: { parts: parts },
      config: config
    }));

    const responseParts = response.candidates?.[0]?.content?.parts;
    if (!responseParts) throw new Error("No content generated.");

    for (const part of responseParts) {
      if (part.inlineData && part.inlineData.data) {
        return part.inlineData.data;
      }
    }
    throw new Error("The model did not return an image.");
  };

  try {
    // Try Primary Model
    return await generate(MODEL_IMAGE_PRIMARY, true);
  } catch (primaryError) {
    console.warn(`Primary model (${MODEL_IMAGE_PRIMARY}) failed. Switching to fallback.`, primaryError);
    
    try {
      // Try Fallback Model (Disable imageSize)
      return await generate(MODEL_IMAGE_FALLBACK, false);
    } catch (fallbackError) {
      console.error("Fallback model also failed:", fallbackError);
      throw primaryError; 
    }
  }
};

/**
 * Edits an existing image with fallback support.
 */
export const editImageWithGemini = async (
  base64Image: string,
  mimeType: string,
  prompt: string,
  referenceImages: string[] = [],
  aspectRatio: AspectRatio = '1:1',
  imageSize: ImageSize = '1K'
): Promise<string> => {
  if (!API_KEY) throw new Error("API Key is missing.");

  const generate = async (model: string, useImageSize: boolean) => {
    const parts: any[] = [];

    // Main image
    parts.push({
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    });

    // References
    for (const ref of referenceImages) {
      parts.push({
        inlineData: {
          data: cleanBase64(ref),
          mimeType: getMimeType(ref),
        }
      });
    }

    // Prompt
    let finalPrompt = prompt;
    if (referenceImages.length > 0) {
      finalPrompt = `${prompt} (Use the provided additional images as reference)`;
    }
    parts.push({ text: finalPrompt });

    const config: any = {
      imageConfig: {
        aspectRatio: aspectRatio,
      }
    };

    if (useImageSize) {
      config.imageConfig.imageSize = imageSize;
    }

    const response = await retryOperation<GenerateContentResponse>(() => ai.models.generateContent({
      model: model,
      contents: { parts: parts },
      config: config
    }));

    const responseParts = response.candidates?.[0]?.content?.parts;
    if (!responseParts) throw new Error("No content generated.");

    for (const part of responseParts) {
      if (part.inlineData && part.inlineData.data) {
        return part.inlineData.data;
      }
    }
    throw new Error("The model did not return an image.");
  };

  try {
    return await generate(MODEL_IMAGE_PRIMARY, true);
  } catch (primaryError) {
    console.warn(`Primary model (${MODEL_IMAGE_PRIMARY}) failed during edit. Switching to fallback.`, primaryError);
    try {
      return await generate(MODEL_IMAGE_FALLBACK, false);
    } catch (fallbackError) {
      console.error("Fallback edit also failed:", fallbackError);
      throw primaryError;
    }
  }
};

/**
 * Removes an object from the image using a mask and optional description.
 * OPTIMIZED: Uses Flash model primarily for speed.
 */
export const removeObjectWithGemini = async (
  base64Image: string,
  mimeType: string,
  base64Mask: string,
  objectDescription: string = ""
): Promise<string> => {
  if (!API_KEY) throw new Error("API Key is missing.");

  const generate = async (model: string) => {
    const parts: any[] = [];

    // 1. Source Image
    parts.push({
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    });

    // 2. Mask Image (Reference)
    parts.push({
      inlineData: {
        data: cleanBase64(base64Mask),
        mimeType: 'image/png',
      }
    });

    // 3. Prompt
    let instruction = "Perform robust image inpainting. The second image provided is a binary mask.";
    instruction += " The white area in the mask indicates the specific region to be edited.";
    instruction += " The black area in the mask indicates the content that must be preserved exactly as is.";
    
    if (objectDescription && objectDescription.trim()) {
      instruction += ` Specifically, identify and remove '${objectDescription}' which is located within the white masked area.`;
    } else {
        instruction += " Identify the object or content within the white masked area and remove it.";
    }
    
    instruction += " Inpaint the removed area to match the surrounding background seamlessly (texture, lighting, and depth).";

    parts.push({ text: instruction });

    const response = await retryOperation<GenerateContentResponse>(() => ai.models.generateContent({
      model: model,
      contents: { parts: parts },
      config: {} 
    }));

    const responseParts = response.candidates?.[0]?.content?.parts;
    if (!responseParts) throw new Error("No content generated.");

    for (const part of responseParts) {
      if (part.inlineData && part.inlineData.data) {
        return part.inlineData.data;
      }
    }
    throw new Error("The model did not return an image.");
  };

  try {
    // Use Flash first for speed
    return await generate(MODEL_IMAGE_FALLBACK);
  } catch (flashError) {
    console.warn(`Fast removal failed. Switching to Pro.`, flashError);
    try {
      return await generate(MODEL_IMAGE_PRIMARY);
    } catch (proError) {
      throw flashError;
    }
  }
};

/**
 * Recolors an object in the image using a mask and target color.
 * OPTIMIZED: Uses Flash model primarily for speed.
 */
export const recolorObjectWithGemini = async (
  base64Image: string,
  mimeType: string,
  base64Mask: string,
  targetColor: string,
  objectDescription: string = ""
): Promise<string> => {
  if (!API_KEY) throw new Error("API Key is missing.");

  const generate = async (model: string) => {
    const parts: any[] = [];

    // 1. Source Image
    parts.push({
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    });

    // 2. Mask Image
    parts.push({
      inlineData: {
        data: cleanBase64(base64Mask),
        mimeType: 'image/png',
      }
    });

    // 3. Prompt - Enhanced for Detail Preservation
    let instruction = "Professional photorealistic image editing. The second image is a binary mask indicating the target area.";
    instruction += ` TARGET TASK: Recolor the surface area defined by the white mask to this color: ${targetColor}.`;
    
    if (objectDescription) {
        instruction += ` CONTEXT & DETAILS: ${objectDescription}.`;
    }
    
    instruction += `
    CRITICAL RULES:
    1. NO SOLID FILL: Do NOT paint a flat or solid color over the object.
    2. PRESERVE DETAILS: You MUST preserve all original underlying textures, wood grains, fabric patterns, surface irregularities, reflections, and shadows.
    3. REALISTIC TINTING: Act like a dye or color filter. Change the hue and saturation of the material while keeping the luminance and texture variations intact.
    4. STRICT MASKING: Only affect the pixels inside the white mask area.
    5. LIGHTING: Ensure the new color interacts correctly with the existing lighting scene.
    `;

    parts.push({ text: instruction });

    const response = await retryOperation<GenerateContentResponse>(() => ai.models.generateContent({
      model: model,
      contents: { parts: parts },
      config: {} 
    }));

    const responseParts = response.candidates?.[0]?.content?.parts;
    if (!responseParts) throw new Error("No content generated.");

    for (const part of responseParts) {
      if (part.inlineData && part.inlineData.data) {
        return part.inlineData.data;
      }
    }
    throw new Error("The model did not return an image.");
  };

  try {
    // Use Flash first for speed
    return await generate(MODEL_IMAGE_FALLBACK);
  } catch (flashError) {
    console.warn(`Fast recolor failed. Switching to Pro.`, flashError);
    try {
      return await generate(MODEL_IMAGE_PRIMARY);
    } catch (proError) {
      throw flashError;
    }
  }
};

/**
 * Analyzes an image and returns text.
 */
export const analyzeImageWithGemini = async (
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  try {
    if (!API_KEY) throw new Error("API Key is missing.");

    const response = await retryOperation<GenerateContentResponse>(() => ai.models.generateContent({
      model: MODEL_TEXT,
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: prompt || "Analyze this image and describe it in detail." },
        ],
      },
    }));

    return response.text || "No analysis provided.";
  } catch (error) {
    console.error("Gemini Analyze Error:", error);
    throw error;
  }
};

/**
 * Generates a video from an image and a text prompt using Veo.
 */
export const generateVideoWithGemini = async (
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  if (!API_KEY) throw new Error("API Key is missing.");

  // Veo Fast is best for responsive feedback
  const model = 'veo-3.1-fast-generate-preview'; 

  // Initiate generation
  // We use 16:9 as a standard cinematic ratio, 720p for speed
  let operation = await ai.models.generateVideos({
    model: model,
    prompt: prompt || "Animate this scene naturally",
    image: {
        imageBytes: base64Image,
        mimeType: mimeType
    },
    config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9' 
    }
  });

  // Polling loop
  while (!operation.done) {
    // Wait 5 seconds between polls
    await new Promise(resolve => setTimeout(resolve, 5000));
    operation = await ai.operations.getVideosOperation({operation: operation});
  }
  
  if (operation.error) {
      throw new Error(`Video generation failed: ${operation.error.message || 'Unknown error'}`);
  }

  const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!videoUri) throw new Error("No video URI generated.");

  // Download video to create a local Data URL so it persists
  const response = await fetch(`${videoUri}&key=${API_KEY}`);
  if (!response.ok) throw new Error("Failed to download video bytes.");
  
  const blob = await response.blob();
  
  return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
  });
};

/**
 * Applies a style transfer from a reference image to a content image.
 */
export const applyStyleWithGemini = async (
  base64Image: string,
  mimeType: string,
  base64Style: string,
  styleMimeType: string,
  intensity: string
): Promise<string> => {
  if (!API_KEY) throw new Error("API Key is missing.");
  
  // Use Pro model for higher understanding of artistic transfer
  const model = MODEL_IMAGE_PRIMARY; 

  const parts: any[] = [];
  
  // 1. Content Image
  parts.push({
      inlineData: {
          data: base64Image,
          mimeType: mimeType
      }
  });

  // 2. Style Reference Image
  parts.push({
      inlineData: {
          data: base64Style,
          mimeType: styleMimeType
      }
  });
  
  // 3. Instruction Prompt
  const prompt = `
    Advanced Style Transfer Task.
    Image 1 is the CONTENT image (structure to preserve).
    Image 2 is the STYLE reference (artistic style to apply).
    
    Instruction: Redraw the Content Image using the visual language, brushwork, color palette, and texture of the Style Reference.
    - PRESERVE the geometry, perspective, and subject of the Content Image exactly.
    - APPLY the artistic style of the Reference Image.
    - Style Intensity: ${intensity}%.
    
    Output the transformed image only.
  `;
  
  parts.push({ text: prompt });

  const response = await retryOperation<GenerateContentResponse>(() => ai.models.generateContent({
      model: model,
      contents: { parts: parts },
      config: {
          imageConfig: { aspectRatio: '1:1' } // Default aspect ratio, or matching source if possible
      }
  }));

  const responseParts = response.candidates?.[0]?.content?.parts;
  if (!responseParts) throw new Error("No content generated.");

  for (const part of responseParts) {
    if (part.inlineData && part.inlineData.data) {
      return part.inlineData.data;
    }
  }
  throw new Error("The model did not return an image.");
};
