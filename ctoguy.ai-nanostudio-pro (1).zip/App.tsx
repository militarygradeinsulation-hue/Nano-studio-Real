
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { 
  Upload, 
  Wand2, 
  History, 
  Download, 
  Undo2, 
  Redo2,
  Image as ImageIcon, 
  Trash2,
  Layers,
  Sparkles,
  AlertCircle,
  Crop as CropIcon,
  Camera,
  RefreshCw,
  Aperture,
  ScanEye,
  Palette,
  Ratio,
  LayoutGrid,
  Eraser,
  Hammer,
  PlusCircle,
  ChevronDown,
  Settings,
  Maximize,
  X,
  Users,
  Zap,
  Ghost,
  Video,
  PaintBucket
} from 'lucide-react';
import { 
  editImageWithGemini, 
  generateImageWithGemini, 
  analyzeImageWithGemini, 
  removeObjectWithGemini, 
  recolorObjectWithGemini,
  generateVideoWithGemini,
  applyStyleWithGemini,
  cleanBase64, 
  getMimeType 
} from './services/geminiService';
import { saveState, loadState } from './services/storageService';
import { HistoryItem, ReferenceImage, EditorMode, AspectRatio, ImageSize } from './types';
import LoadingOverlay from './components/LoadingOverlay';
import Button from './components/Button';
import ReferencePanel from './components/ReferencePanel';
import ImageTransformer from './components/ImageTransformer';
import MaskEditor from './components/MaskEditor';
import ColorChangeTool from './components/ColorChangeTool';
import StyleTransferTool from './components/StyleTransferTool';

const App: React.FC = () => {
  // --- State ---
  const [mode, setMode] = useState<EditorMode>(EditorMode.GENERATE);
  
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [currentVideo, setCurrentVideo] = useState<string | null>(null); // State for generated video
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [future, setFuture] = useState<HistoryItem[]>([]); // For Redo
  
  const [referenceImages, setReferenceImages] = useState<ReferenceImage[]>([]);
  const [prompt, setPrompt] = useState('');
  
  // Settings
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [imageSize, setImageSize] = useState<ImageSize>('1K');

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Overlay Modes
  const [isTransformMode, setIsTransformMode] = useState(false);
  const [isRemoveMode, setIsRemoveMode] = useState(false);
  const [isColorMode, setIsColorMode] = useState(false);
  const [isStyleMode, setIsStyleMode] = useState(false);

  // Park Builder State
  const [uploadedModel, setUploadedModel] = useState<string | null>(null);

  // Persistence State
  const [isRestored, setIsRestored] = useState(false);

  // Sidebar State (Active Tab)
  type SidebarTab = 'settings' | 'park' | 'references' | 'history' | null;
  const [activeTab, setActiveTab] = useState<SidebarTab>('settings');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const parkModelInputRef = useRef<HTMLInputElement>(null);
  const magicBlendInputRef = useRef<HTMLInputElement>(null);
  const magicBlendNoKidsInputRef = useRef<HTMLInputElement>(null);

  // --- Persistence Effects ---
  useEffect(() => {
    const restore = async () => {
      try {
        const [
            sMode, sOrig, sCurr, sHist, sFut, sRefs, sModel
        ] = await Promise.all([
            loadState('mode'),
            loadState('originalImage'),
            loadState('currentImage'),
            loadState('history'),
            loadState('future'),
            loadState('referenceImages'),
            loadState('uploadedModel')
        ]);

        if (sMode) setMode(sMode);
        if (sOrig) setOriginalImage(sOrig);
        if (sCurr) setCurrentImage(sCurr);
        if (sHist && Array.isArray(sHist)) setHistory(sHist);
        if (sFut && Array.isArray(sFut)) setFuture(sFut);
        if (sRefs && Array.isArray(sRefs)) setReferenceImages(sRefs);
        if (sModel) setUploadedModel(sModel);
        
      } catch (e) {
        console.error("State restoration failed", e);
      } finally {
        setIsRestored(true);
      }
    };
    restore();
  }, []);

  useEffect(() => {
    if (!isRestored) return;
    
    // Save state changes to IndexedDB
    saveState('mode', mode);
    saveState('originalImage', originalImage);
    saveState('currentImage', currentImage);
    saveState('history', history);
    saveState('future', future);
    saveState('referenceImages', referenceImages);
    saveState('uploadedModel', uploadedModel);

  }, [mode, originalImage, currentImage, history, future, referenceImages, uploadedModel, isRestored]);


  // --- Handlers ---

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setOriginalImage(result);
      setCurrentImage(result);
      setCurrentVideo(null);
      setHistory([]);
      setFuture([]);
      setError(null);
      setAnalysisResult(null);
      // Auto-switch to Edit if we were in Generate
      if (mode === EditorMode.GENERATE) setMode(EditorMode.EDIT);
    };
    reader.readAsDataURL(file);
  };

  const pushToHistory = (newItem: HistoryItem) => {
    setHistory(prev => [newItem, ...prev]);
    setFuture([]); // Clear future on new action
  };

  const handleGenerate = useCallback(async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt.");
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setCurrentVideo(null); // Reset video view when starting new op

    try {
      let newImageBase64 = '';
      let mimeType = 'image/png';

      if (mode === EditorMode.GENERATE) {
        // Text to Image (with optional references)
        const refImageUrls = referenceImages.map(r => r.url);
        newImageBase64 = await generateImageWithGemini(prompt, refImageUrls, aspectRatio, imageSize);
        mimeType = 'image/png'; // Default for gen
        
        const newImageUrl = `data:${mimeType};base64,${newImageBase64}`;
        
        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage || newImageUrl, 
            prompt: prompt,
            timestamp: Date.now(),
            mode: mode
        });

        setCurrentImage(newImageUrl);
        if (!currentImage) setOriginalImage(newImageUrl); 

      } else if (mode === EditorMode.EDIT) {
        // Image to Image
        if (!currentImage) throw new Error("No image to edit.");
        
        const cleanData = cleanBase64(currentImage);
        const imgMime = getMimeType(currentImage);
        const refImageUrls = referenceImages.map(r => r.url);

        const consistencyPrompt = `${prompt} \n\nCRITICAL INSTRUCTION: You are editing a specific playground structure. The equipment structure, colors, design, and features MUST remain 100% IDENTICAL to the source image. Do not hallucinate new features or change the model. If zooming out, changing angle, or panning, expand the environment (grass, mulch, sky) but preserve the playground equipment EXACTLY as it is in the original image.`;

        newImageBase64 = await editImageWithGemini(cleanData, imgMime, consistencyPrompt, refImageUrls, aspectRatio, imageSize);
        const newImageUrl = `data:${imgMime};base64,${newImageBase64}`;

        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage, 
            prompt: prompt, 
            timestamp: Date.now(),
            mode: mode
        });

        setCurrentImage(newImageUrl);

      } else if (mode === EditorMode.VIDEO) {
        // Video Generation
        if (!currentImage) throw new Error("No image to animate. Upload or generate an image first.");
        
        const cleanData = cleanBase64(currentImage);
        const imgMime = getMimeType(currentImage);
        
        const videoUrl = await generateVideoWithGemini(cleanData, imgMime, prompt);
        setCurrentVideo(videoUrl);
        
        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            videoUrl: videoUrl,
            prompt: "Video Generation: " + prompt,
            timestamp: Date.now(),
            mode: mode
        });

      } else if (mode === EditorMode.ANALYZE) {
        // Image to Text
        if (!currentImage) throw new Error("No image to analyze.");
        const cleanData = cleanBase64(currentImage);
        const imgMime = getMimeType(currentImage);
        
        const text = await analyzeImageWithGemini(cleanData, imgMime, prompt);
        setAnalysisResult(text);
      }

      setPrompt('');
    } catch (err: any) {
      setError(err.message || "Operation failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [currentImage, prompt, referenceImages, mode, aspectRatio, imageSize]);

  const handleRegenerate = useCallback(async () => {
    // Basic regenerate for EDIT/GENERATE modes
    if (history.length === 0 && mode !== EditorMode.GENERATE) return;
    
    setIsLoading(true);
    setError(null);

    try {
        let promptToUse = prompt.trim();
        
        if (mode === EditorMode.GENERATE) {
             if (!promptToUse && history.length > 0) promptToUse = history[0].prompt;
             if (!promptToUse) throw new Error("No prompt available");
             
             const refImageUrls = referenceImages.map(r => r.url);
             const newImageBase64 = await generateImageWithGemini(promptToUse, refImageUrls, aspectRatio, imageSize);
             setCurrentImage(`data:image/png;base64,${newImageBase64}`);
        } 
        else if (mode === EditorMode.EDIT && history.length > 0) {
            const sourceState = history[0];
            
            const cleanData = cleanBase64(sourceState.imageUrl);
            const mimeType = getMimeType(sourceState.imageUrl);
            const refImageUrls = referenceImages.map(r => r.url);
            
            if (!promptToUse) promptToUse = sourceState.prompt;

            // Inject a variance instruction to ensure a new result
            const variants = ["(Variation: Different lighting)", "(Variation: Slight angle shift)", "(Variation: Different atmosphere)", "(Variation: Fresh take)"];
            const randomVariant = variants[Math.floor(Math.random() * variants.length)];
            
            const consistencyPrompt = `${promptToUse} ${randomVariant} \n\nCRITICAL INSTRUCTION: Keep the playground equipment 100% IDENTICAL to the source image. Do not change the design. Create a distinct new generation based on the previous prompt.`;

            const newImageBase64 = await editImageWithGemini(cleanData, mimeType, consistencyPrompt, refImageUrls, aspectRatio, imageSize);
            setCurrentImage(`data:${mimeType};base64,${newImageBase64}`);
        }
    } catch (err: any) {
        setError(err.message || "Failed to regenerate.");
    } finally {
        setIsLoading(false);
    }
  }, [history, currentImage, prompt, referenceImages, mode, aspectRatio, imageSize]);

  // --- History Management (Undo/Redo) ---

  const handleUndo = () => {
    if (history.length === 0) return;
    
    // Current state -> Future
    if (currentImage) {
        setFuture(prev => [{
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            prompt: "Undo State",
            timestamp: Date.now(),
            mode: mode
        }, ...prev]);
    }

    const previousState = history[0];
    setCurrentImage(previousState.imageUrl);
    if (previousState.videoUrl) setCurrentVideo(previousState.videoUrl);
    else setCurrentVideo(null);
    
    setHistory(prev => prev.slice(1));
  };

  const handleRedo = () => {
    if (future.length === 0) return;

    // Current state -> History
    if (currentImage) {
        setHistory(prev => [{
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            prompt: "Redo State",
            timestamp: Date.now(),
            mode: mode
        }, ...prev]);
    }

    const nextState = future[0];
    setCurrentImage(nextState.imageUrl);
    if (nextState.videoUrl) setCurrentVideo(nextState.videoUrl);
    else setCurrentVideo(null);

    setFuture(prev => prev.slice(1));
  };

  const handleReset = () => {
    if (originalImage) {
      setCurrentImage(originalImage);
      setCurrentVideo(null);
      setHistory([]);
      setFuture([]);
      setAnalysisResult(null);
    } else {
      setCurrentImage(null);
      setCurrentVideo(null);
      setHistory([]);
      setFuture([]);
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    
    if (mode === EditorMode.VIDEO && currentVideo) {
        link.href = currentVideo;
        link.download = `ctoguy-nano-pro-${Date.now()}.mp4`;
    } else if (currentImage) {
        link.href = currentImage;
        link.download = `ctoguy-nano-pro-${Date.now()}.png`;
    } else {
        return;
    }
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- Park Builder Handlers ---

  const handleGenerateParkBase = async () => {
    setIsLoading(true);
    setError(null);
    setMode(EditorMode.GENERATE);
    setCurrentVideo(null);
    
    // Updated prompt to be strictly empty
    const parkPrompt = "Professional architectural photography of a completely empty playground site. A large, flat rectangular area of wood mulch safety surfacing. The area is strictly empty with NO playground equipment, NO poles, and NO structures. The mulch area is surrounded by a clean 2x2 timber border. Green grass surrounds the outside of the timber border. Sunny day, realistic, 8k resolution, eye level view.";

    try {
        const newImageBase64 = await generateImageWithGemini(parkPrompt, [], "16:9", "2K");
        const newImageUrl = `data:image/png;base64,${newImageBase64}`;
        
        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage || newImageUrl,
            prompt: "Generate Park Base",
            timestamp: Date.now(),
            mode: EditorMode.GENERATE
        });

        setCurrentImage(newImageUrl);
        if (!originalImage) setOriginalImage(newImageUrl);
    } catch (err: any) {
        setError(err.message);
    } finally {
        setIsLoading(false);
    }
  };

  const performModelPlacement = async (baseImg: string, modelImg: string) => {
        setIsLoading(true);
        setError(null);
        setMode(EditorMode.EDIT);
        setCurrentVideo(null);

        try {
            const baseClean = cleanBase64(baseImg);
            const baseMime = getMimeType(baseImg);
            
            // STRICT PROMPT FOR PHYSICS, SHADOWS, AND REALISM
            const compositePrompt = `
              Professional Architectural Integration:
              Place the provided playground equipment into the wood mulch area with strict physics and lighting accuracy.
              
              1. SCALE & PERSPECTIVE: Scale the playground equipment UP significantly. It must look large and heavy, not like a toy. It should occupy about 80% of the mulch area. The camera angle of the equipment MUST match the background perspective.
              
              2. GRAVITY & GROUNDING: The equipment posts must look BURRIED into the wood chips. They cannot float. The wood chips should pile slightly around the base of the posts and slides.
              
              3. SHADOWS (CRITICAL): Cast hard, realistic shadows from the structure onto the wood mulch. The shadows must match the direction and intensity of the sun in the background scene. Also add ambient occlusion shadows where metal parts touch the ground.
              
              4. SAFETY ZONES (STRICT): You MUST maintain a visible, clear fall zone of at least 6-10 feet between any part of the playground equipment and the surrounding timber border. The equipment must NOT touch or overlap the border at any point. Center the equipment within this safe zone.
              
              5. IDENTITY: Keep the equipment colors and design 100% identical to the reference image.
            `;

            const newImageBase64 = await editImageWithGemini(
                baseClean, 
                baseMime, 
                compositePrompt, 
                [modelImg], 
                "16:9", 
                "2K"
            );
            
            const newImageUrl = `data:${baseMime};base64,${newImageBase64}`;

            pushToHistory({
                id: crypto.randomUUID(),
                imageUrl: baseImg,
                prompt: "Place Playground Model",
                timestamp: Date.now(),
                mode: EditorMode.EDIT
            });

            setCurrentImage(newImageUrl);
        } catch (err: any) {
            setError(err.message || "Failed to place model.");
        } finally {
            setIsLoading(false);
        }
  };

  const handlePlacePlaygroundModel = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !currentImage) {
        if (!currentImage) setError("Please generate or upload a park base first.");
        return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
        const modelBase64 = e.target?.result as string;
        setUploadedModel(modelBase64);
        await performModelPlacement(currentImage!, modelBase64);
        
        if (parkModelInputRef.current) parkModelInputRef.current.value = '';
    };
    reader.readAsDataURL(file);
  };

  const handleMagicBuild = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
        const modelBase64 = e.target?.result as string;
        setUploadedModel(modelBase64);
        setOriginalImage(modelBase64); // Save the raw model as original
        setCurrentImage(modelBase64);
        setCurrentVideo(null);
        
        // Start Magic Blend
        setIsLoading(true);
        setError(null);
        setMode(EditorMode.EDIT);
        
        try {
            const cleanModel = cleanBase64(modelBase64);
            const mime = getMimeType(modelBase64);
            
            const magicPrompt = `
                TOTAL SCENE TRANSFORMATION (MAGIC BLEND):
                Transform this white-background/model image into a stunning photorealistic park scene.
                
                1. ENVIRONMENT: Place the playground equipment on a realistic wood mulch surface, surrounded by a 2x2 timber border. Add green grass and trees in the background. Sunny day with blue sky.
                2. INTEGRATION: The equipment must look firmly anchored in the ground. Add cast shadows from the sun.
                3. HYPER-REALISTIC LIFE: Add diverse children with true physics. They must have motion blur on moving limbs, realistic skin textures with subsurface scattering, and correct weight distribution (holding on, leaning, sitting). They must cast accurate shadows on the mulch and equipment. Avoid 'floating' or 'sticker' look.
                4. CONSISTENCY: Keep the playground equipment design and colors EXACTLY the same as the source image.
                5. QUALITY: 4K, Architectural photography style.
            `;
            
            const newImageBase64 = await editImageWithGemini(
                cleanModel,
                mime,
                magicPrompt,
                [], // No extra refs needed, the input IS the ref
                "16:9",
                "2K"
            );
            
            const newImageUrl = `data:${mime};base64,${newImageBase64}`;
            
             pushToHistory({
                id: crypto.randomUUID(),
                imageUrl: modelBase64,
                prompt: "Magic Blend (One-Click Build)",
                timestamp: Date.now(),
                mode: EditorMode.EDIT
            });
            
            setCurrentImage(newImageUrl);
            
        } catch (err: any) {
            setError(err.message || "Magic blend failed.");
        } finally {
            setIsLoading(false);
        }
        
        if (magicBlendInputRef.current) magicBlendInputRef.current.value = '';
    };
    reader.readAsDataURL(file);
  }

  const handleMagicBuildNoKids = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
        const modelBase64 = e.target?.result as string;
        setUploadedModel(modelBase64);
        setOriginalImage(modelBase64); // Save the raw model as original
        setCurrentImage(modelBase64);
        setCurrentVideo(null);
        
        // Start Magic Blend No Kids
        setIsLoading(true);
        setError(null);
        setMode(EditorMode.EDIT);
        
        try {
            const cleanModel = cleanBase64(modelBase64);
            const mime = getMimeType(modelBase64);
            
            const magicPrompt = `
                TOTAL SCENE TRANSFORMATION (MAGIC BLEND - EMPTY):
                Transform this white-background/model image into a stunning photorealistic park scene.
                
                1. ENVIRONMENT: Place the playground equipment on a realistic wood mulch surface, surrounded by a 2x2 timber border. Add green grass and trees in the background. Sunny day with blue sky.
                2. INTEGRATION: The equipment must look firmly anchored in the ground. Add cast shadows from the sun.
                3. ATMOSPHERE: The scene must be completely EMPTY of people. No children, no adults. Just the playground architecture in a beautiful landscape.
                4. CONSISTENCY: Keep the playground equipment design and colors EXACTLY the same as the source image.
                5. QUALITY: 4K, Architectural photography style.
            `;
            
            const newImageBase64 = await editImageWithGemini(
                cleanModel,
                mime,
                magicPrompt,
                [], // No extra refs needed, the input IS the ref
                "16:9",
                "2K"
            );
            
            const newImageUrl = `data:${mime};base64,${newImageBase64}`;
            
             pushToHistory({
                id: crypto.randomUUID(),
                imageUrl: modelBase64,
                prompt: "Magic Blend (No Kids)",
                timestamp: Date.now(),
                mode: EditorMode.EDIT
            });
            
            setCurrentImage(newImageUrl);
            
        } catch (err: any) {
            setError(err.message || "Magic blend failed.");
        } finally {
            setIsLoading(false);
        }
        
        if (magicBlendNoKidsInputRef.current) magicBlendNoKidsInputRef.current.value = '';
    };
    reader.readAsDataURL(file);
  }

  const handleRedoPlacement = async () => {
    if (!uploadedModel) {
        setError("No uploaded model to place.");
        return;
    }

    let baseImageToUse = currentImage;
    
    // If the last action was already a placement, we want to use the state BEFORE that placement
    // so we don't place a model on top of another model.
    if (history.length > 0 && history[0].prompt === "Place Playground Model") {
        baseImageToUse = history[0].imageUrl;
    }

    if (!baseImageToUse) {
        setError("No base image available.");
        return;
    }

    await performModelPlacement(baseImageToUse, uploadedModel);
  };

  const handleAddKidsPlaying = async () => {
    if (!currentImage) {
        setError("No playground image available. Please build a park or upload an image first.");
        return;
    }
    
    setIsLoading(true);
    setError(null);
    setMode(EditorMode.EDIT);
    setCurrentVideo(null);

    try {
        const baseClean = cleanBase64(currentImage);
        const baseMime = getMimeType(currentImage);
        
        const kidsPrompt = "Add diverse happy children playing on the playground equipment and running on the wood mulch surfacing. Ensure they are realistically interacting with the slides, climbers, and swings. Match the lighting, shadows, and perspective of the existing scene perfectly. High quality, photorealistic, joyous atmosphere.";

        const newImageBase64 = await editImageWithGemini(
            baseClean, 
            baseMime, 
            kidsPrompt, 
            [], 
            "16:9", 
            "2K"
        );
        
        const newImageUrl = `data:${baseMime};base64,${newImageBase64}`;

        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            prompt: "Add Kids Playing",
            timestamp: Date.now(),
            mode: EditorMode.EDIT
        });

        setCurrentImage(newImageUrl);
    } catch (err: any) {
        setError(err.message || "Failed to add kids.");
    } finally {
        setIsLoading(false);
    }
  };


  // --- Pro Shot Handlers ---
  const getRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

  const handleProShot = () => {
    // Dynamic Single Shot
    const angles = [
        "Low angle looking up at the child",
        "Eye-level candid shot",
        "High angle looking down",
        "Framed through a playground tunnel",
        "Side profile capturing movement"
    ];
    const actions = [
        "laughing while sliding",
        "concentrating on climbing",
        "peeking through a window",
        "hanging from a bar",
        "running towards the camera"
    ];
    const lighting = [
        "with golden hour backlighting",
        "in bright sunny daylight",
        "with soft overcast lighting",
        "with dynamic shadows"
    ];

    const smartPrompt = `Professional photographic close-up of a SINGLE child ${getRandom(actions)}, ${getRandom(angles)}, ${getRandom(lighting)}. ANALYZE SCENE: Identify a specific component (slide, climber, net) and show interaction. CONSTRAINT: The playground equipment colors, materials, and design MUST remain 100% identical to the original image. Do not change the structure. Photorealistic, sun-drenched, shallow depth of field.`;
    setPrompt(smartPrompt);
  };

  const handleProShotGroup = () => {
    // Dynamic Group Shot
    const scenarios = [
        "Kids racing each other down the slides",
        "One child helping another climb up a step",
        "A group huddled together inside a tunnel laughing",
        "Playing tag around the structure",
        "Sitting together on a platform chatting"
    ];
    
    const smartPrompt = `Professional lifestyle photography of a GROUP of happy children. SCENARIO: ${getRandom(scenarios)}. ACTION: Capture a candid moment of 3-4 kids interacting with each other and the equipment. CONSTRAINT: The playground equipment design, colors, and materials MUST remain 100% identical to the source image. Photorealistic, dynamic angle.`;
    setPrompt(smartPrompt);
  };

  const handleCollageShot = () => {
    // Dynamic Collage
    const styles = [
        "Focus heavily on textures (ropes, plastic, wood) mixed with smiles",
        "Focus on action and motion blur",
        "A mix of wide environmental shots and tight detail shots",
        "Vertical panel layout showing height and climbing"
    ];

    const smartPrompt = `A dynamic 3-panel split-screen photo collage of children playing on this playground. STYLE: ${getRandom(styles)}. ANALYZE SCENE: Use the actual equipment visible to frame the shots. CONSTRAINT: All playground equipment in the collage MUST match the source image exactly.`;
    setPrompt(smartPrompt);
  };

  // --- Reference Management ---
  
  const addReferences = (urls: string[]) => {
    setReferenceImages(prev => {
        const availableSlots = 10 - prev.length; 
        if (availableSlots <= 0) return prev;
        const newUrls = urls.slice(0, availableSlots);
        const newRefs = newUrls.map(url => ({ id: crypto.randomUUID(), url }));
        return [...prev, ...newRefs];
    });
  };

  const removeReference = (id: string) => {
    setReferenceImages(prev => prev.filter(r => r.id !== id));
  };

  // --- Transformer Handlers ---

  const handleTransformSave = (newImage: string) => {
    if (currentImage) {
        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            prompt: "Transform (Crop/Resize)",
            timestamp: Date.now(),
            mode: EditorMode.TRANSFORM
        });
    }
    setCurrentImage(newImage);
    setIsTransformMode(false);
  };

  // --- Removal Handlers ---
  const handleRemoveSave = async (maskBase64: string, removePrompt: string) => {
    setIsRemoveMode(false);
    if (!currentImage) return;

    setIsLoading(true);
    setError(null);
    
    try {
        const cleanImg = cleanBase64(currentImage);
        const mime = getMimeType(currentImage);
        const cleanMask = cleanBase64(maskBase64);
        
        const newImageBase64 = await removeObjectWithGemini(cleanImg, mime, cleanMask, removePrompt);
        const newImageUrl = `data:${mime};base64,${newImageBase64}`;

        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            prompt: removePrompt || "Object Removal",
            timestamp: Date.now(),
            mode: EditorMode.REMOVE
        });

        setCurrentImage(newImageUrl);
    } catch (err: any) {
        setError(err.message || "Failed to remove object.");
    } finally {
        setIsLoading(false);
    }
  };

  // --- Color Handlers ---
  const handleColorSave = async (maskBase64: string, targetColor: string, colorPrompt: string) => {
      setIsColorMode(false);
      if (!currentImage) return;

      setIsLoading(true);
      setError(null);

      try {
          const cleanImg = cleanBase64(currentImage);
          const mime = getMimeType(currentImage);
          const cleanMask = cleanBase64(maskBase64);

          const newImageBase64 = await recolorObjectWithGemini(cleanImg, mime, cleanMask, targetColor, colorPrompt);
          const newImageUrl = `data:${mime};base64,${newImageBase64}`;

          pushToHistory({
              id: crypto.randomUUID(),
              imageUrl: currentImage,
              prompt: `Recolor to ${targetColor}` + (colorPrompt ? `: ${colorPrompt}` : ''),
              timestamp: Date.now(),
              mode: EditorMode.COLOR
          });

          setCurrentImage(newImageUrl);
      } catch (err: any) {
          setError(err.message || "Failed to recolor object.");
      } finally {
          setIsLoading(false);
      }
  };

  // --- Style Handlers ---
  const handleStyleSave = async (styleImage: string, intensity: string) => {
    setIsStyleMode(false);
    if (!currentImage) return;

    setIsLoading(true);
    setError(null);

    try {
        const cleanImg = cleanBase64(currentImage);
        const mime = getMimeType(currentImage);
        const cleanStyle = cleanBase64(styleImage);
        const styleMime = getMimeType(styleImage);

        const newImageBase64 = await applyStyleWithGemini(cleanImg, mime, cleanStyle, styleMime, intensity);
        const newImageUrl = `data:${mime};base64,${newImageBase64}`;

        pushToHistory({
            id: crypto.randomUUID(),
            imageUrl: currentImage,
            prompt: `Style Transfer (${intensity})`,
            timestamp: Date.now(),
            mode: EditorMode.STYLE
        });

        setCurrentImage(newImageUrl);
    } catch (err: any) {
        setError(err.message || "Style transfer failed.");
    } finally {
        setIsLoading(false);
    }
  };

  // --- UI Components ---

  const TabIcon = ({ id, icon, label }: { id: SidebarTab, icon: React.ReactNode, label: string }) => (
      <button 
        onClick={() => setActiveTab(activeTab === id ? null : id)}
        className={`flex flex-col items-center justify-center w-12 h-12 rounded-lg transition-all duration-200 group relative ${
            activeTab === id 
            ? 'text-studio-accent bg-studio-800' 
            : 'text-slate-500 hover:text-slate-200 hover:bg-studio-800/50'
        }`}
        title={label}
      >
        {icon}
        <span className="absolute left-full ml-2 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50">
            {label}
        </span>
      </button>
  );

  const SidebarRail = () => (
    <div className="w-16 flex-shrink-0 bg-studio-900 border-r border-studio-700 flex flex-col items-center py-4 gap-2 z-40">
        <TabIcon id="settings" icon={<Settings className="w-6 h-6"/>} label="Settings" />
        <TabIcon id="park" icon={<Hammer className="w-6 h-6"/>} label="Park Builder" />
        
        {(mode === EditorMode.EDIT || mode === EditorMode.GENERATE || mode === EditorMode.VIDEO || mode === EditorMode.STYLE) && (
             <TabIcon id="references" icon={<ImageIcon className="w-6 h-6"/>} label="References" />
        )}
        
        <div className="flex-1" /> 
        
        <TabIcon id="history" icon={<History className="w-6 h-6"/>} label="History" />
    </div>
  );

  const SidebarPanel = () => {
      if (!activeTab) return null;

      return (
          <div className="w-72 bg-studio-800 border-r border-studio-700 flex flex-col h-full shadow-xl animate-in slide-in-from-left-5 duration-200 z-30">
              <div className="h-14 flex items-center justify-between px-4 border-b border-studio-700 flex-shrink-0">
                  <h3 className="font-semibold text-white text-sm uppercase tracking-wider">
                      {activeTab === 'settings' && 'Configuration'}
                      {activeTab === 'park' && 'Park Builder'}
                      {activeTab === 'references' && 'Reference Images'}
                      {activeTab === 'history' && 'History'}
                  </h3>
                  <button onClick={() => setActiveTab(null)} className="text-slate-500 hover:text-white">
                      <X className="w-4 h-4" />
                  </button>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                  {activeTab === 'settings' && (
                    <div className="space-y-6">
                         <div className="text-xs text-slate-500 mb-4 bg-studio-900 p-2 rounded border border-studio-700">
                             Current Mode: <span className="text-studio-accent font-bold">{mode}</span>
                         </div>

                        {(mode === EditorMode.GENERATE || mode === EditorMode.EDIT) ? (
                            <div className="space-y-6">
                                <div>
                                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center">
                                        <Ratio className="w-3 h-3 mr-1" /> Aspect Ratio
                                    </label>
                                    <div className="grid grid-cols-4 gap-2">
                                        {['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'].map((ratio) => (
                                            <button
                                                key={ratio}
                                                onClick={() => setAspectRatio(ratio as AspectRatio)}
                                                className={`text-[10px] py-2 rounded border transition-colors ${
                                                    aspectRatio === ratio 
                                                    ? 'bg-studio-accent text-white border-studio-accent' 
                                                    : 'bg-studio-900 text-slate-400 border-studio-700 hover:border-slate-500'
                                                }`}
                                            >
                                                {ratio}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center">
                                        <MaximizeIcon className="w-3 h-3 mr-1" /> Quality / Size
                                    </label>
                                    <div className="flex space-x-2 bg-studio-900 p-1 rounded-lg border border-studio-700">
                                        {['1K', '2K', '4K'].map((size) => (
                                            <button
                                                key={size}
                                                onClick={() => setImageSize(size as ImageSize)}
                                                className={`flex-1 text-xs py-1.5 rounded-md transition-all ${
                                                    imageSize === size
                                                    ? 'bg-studio-700 text-white shadow-sm'
                                                    : 'text-slate-400 hover:text-white'
                                                }`}
                                            >
                                                {size}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="text-sm text-slate-400 text-center py-8">
                                Settings not available in {mode} mode.
                            </div>
                        )}
                    </div>
                  )}

                  {activeTab === 'park' && (
                      <div className="space-y-4">
                        <p className="text-xs text-slate-400 mb-2">
                            Build realistic playground environments.
                        </p>
                        
                        {/* New Magic Blend Button (With Kids) */}
                         <Button 
                            variant="primary" 
                            size="sm" 
                            className="w-full justify-start bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 border-none shadow-lg shadow-cyan-900/20"
                            onClick={() => magicBlendInputRef.current?.click()}
                        >
                            <Zap className="w-4 h-4 mr-2 text-white" />
                            Magic Blend (One-Click)
                        </Button>
                        <input 
                            type="file" 
                            ref={magicBlendInputRef} 
                            className="hidden" 
                            accept="image/*" 
                            onChange={handleMagicBuild}
                        />

                        {/* New Magic Blend Button (No Kids) */}
                        <Button 
                            variant="primary" 
                            size="sm" 
                            className="w-full justify-start bg-gradient-to-r from-slate-600 to-slate-500 hover:from-slate-500 hover:to-slate-400 border-none shadow-lg shadow-slate-900/20"
                            onClick={() => magicBlendNoKidsInputRef.current?.click()}
                        >
                            <Ghost className="w-4 h-4 mr-2 text-white" />
                            Magic Blend (No Kids)
                        </Button>
                        <input 
                            type="file" 
                            ref={magicBlendNoKidsInputRef} 
                            className="hidden" 
                            accept="image/*" 
                            onChange={handleMagicBuildNoKids}
                        />

                        <p className="text-[10px] text-slate-500 mb-4 px-1">
                            Upload a model -> Auto-creates park, placement & environment in one step.
                        </p>

                        <div className="h-px bg-studio-700 my-2"></div>
                        
                        <Button 
                            variant="secondary" 
                            size="sm" 
                            className="w-full justify-start"
                            onClick={handleGenerateParkBase}
                        >
                            <Layers className="w-4 h-4 mr-2 text-studio-accent" />
                            Build Park Base
                        </Button>
                        <Button 
                            variant="secondary" 
                            size="sm" 
                            className="w-full justify-start"
                            onClick={() => parkModelInputRef.current?.click()}
                            disabled={!currentImage}
                        >
                            <PlusCircle className="w-4 h-4 mr-2 text-green-400" />
                            Place Model (Upload)
                        </Button>
                        <input 
                            type="file" 
                            ref={parkModelInputRef} 
                            className="hidden" 
                            accept="image/*" 
                            onChange={handlePlacePlaygroundModel}
                        />
                         {uploadedModel && (
                            <Button 
                                variant="secondary" 
                                size="sm" 
                                className="w-full justify-start mt-2"
                                onClick={handleRedoPlacement}
                            >
                                <RefreshCw className="w-4 h-4 mr-2 text-orange-400" />
                                Redo Placement
                            </Button>
                        )}
                        
                        <Button 
                            variant="secondary" 
                            size="sm" 
                            className="w-full justify-start mt-2"
                            onClick={handleAddKidsPlaying}
                            disabled={!currentImage}
                        >
                            <Users className="w-4 h-4 mr-2 text-pink-400" />
                            Add Kids Playing
                        </Button>
                      </div>
                  )}

                  {activeTab === 'references' && (
                      <ReferencePanel 
                        references={referenceImages} 
                        onAdd={addReferences} 
                        onRemove={removeReference} 
                      />
                  )}

                  {activeTab === 'history' && (
                      <div className="space-y-4">
                        {history.length === 0 && (
                            <div className="text-center text-slate-500 text-sm py-8 italic">
                                No history yet.
                            </div>
                        )}
                        {history.map((item) => (
                            <div 
                                key={item.id} 
                                className="group relative bg-studio-900 rounded-lg overflow-hidden border border-studio-700 hover:border-studio-accent transition-colors cursor-pointer"
                                onClick={() => {
                                    setCurrentImage(item.imageUrl);
                                    if (item.videoUrl) {
                                        setMode(EditorMode.VIDEO);
                                        setCurrentVideo(item.videoUrl);
                                    } else {
                                        setMode(item.mode || EditorMode.EDIT);
                                        setCurrentVideo(null);
                                    }
                                }}
                            >
                                <img src={item.imageUrl} alt="History thumbnail" className="w-full h-24 object-cover opacity-70 group-hover:opacity-100 transition-opacity" />
                                {item.videoUrl && (
                                    <div className="absolute top-2 right-2 bg-black/60 rounded-full p-1 text-white">
                                        <Video className="w-3 h-3" />
                                    </div>
                                )}
                                <div className="absolute bottom-0 left-0 right-0 bg-black/80 p-2 text-[10px] text-white backdrop-blur-sm truncate border-t border-white/10">
                                    {item.prompt || "Untitled"}
                                </div>
                            </div>
                        ))}
                      </div>
                  )}
              </div>
              
              <div className="p-4 border-t border-studio-700 mt-auto">
                {currentImage && (
                    <Button variant="secondary" className="w-full text-xs" onClick={handleReset} icon={<Trash2 className="w-3 h-3"/>}>
                    Reset Workspace
                    </Button>
                )}
              </div>
          </div>
      );
  };

  const ModeSelector = () => (
    <div className="flex items-center space-x-1 bg-studio-800 p-1 rounded-lg border border-studio-700">
        <button
            onClick={() => setMode(EditorMode.GENERATE)}
            className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center ${
                mode === EditorMode.GENERATE ? 'bg-studio-accent text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
        >
            <Palette className="w-4 h-4 mr-2" /> <span className="hidden sm:inline">Generate</span>
        </button>
        <button
            onClick={() => setMode(EditorMode.EDIT)}
            className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center ${
                mode === EditorMode.EDIT ? 'bg-studio-accent text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
        >
            <Wand2 className="w-4 h-4 mr-2" /> <span className="hidden sm:inline">Edit</span>
        </button>
        <button
            onClick={() => {
                setMode(EditorMode.VIDEO);
                setCurrentVideo(null); // Clear previous video view
            }}
            className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center ${
                mode === EditorMode.VIDEO ? 'bg-studio-accent text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
        >
            <Video className="w-4 h-4 mr-2" /> <span className="hidden sm:inline">Video</span>
        </button>
        <button
            onClick={() => setMode(EditorMode.ANALYZE)}
            className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center ${
                mode === EditorMode.ANALYZE ? 'bg-studio-accent text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
        >
            <ScanEye className="w-4 h-4 mr-2" /> <span className="hidden sm:inline">Analyze</span>
        </button>
    </div>
  );

  const EmptyState = () => (
    <div className="flex flex-col items-center justify-center h-full text-center p-8">
      <div className="w-24 h-24 bg-studio-800 rounded-full flex items-center justify-center mb-6 animate-pulse-slow">
        <ImageIcon className="w-10 h-10 text-studio-accent" />
      </div>
      <h1 className="text-3xl font-bold text-white mb-2">Ctoguy Nano Pro</h1>
      <p className="text-slate-400 max-w-md mb-8">
        The ultimate AI playground design studio. Upload models, build parks, and bring scenes to life with Gemini 3 Pro.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <Button 
            size="lg" 
            onClick={() => setMode(EditorMode.GENERATE)}
            icon={<Palette className="w-5 h-5"/>}
        >
            Start Generating
        </Button>
        <Button 
            size="lg" 
            variant="secondary"
            onClick={() => fileInputRef.current?.click()}
            icon={<Upload className="w-5 h-5"/>}
        >
            Upload Image
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-[100dvh] w-full bg-studio-900 text-white font-sans selection:bg-studio-accent selection:text-white overflow-hidden">
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="image/*" 
        className="hidden" 
      />

      {/* Navigation Rail */}
      <SidebarRail />

      {/* Collapsible Panel */}
      <SidebarPanel />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 relative h-full">
        
        {/* Header Toolbar */}
        <div className="h-16 bg-studio-900 border-b border-studio-700 flex items-center justify-between px-4 md:px-6 z-10 flex-shrink-0">
          <div className="flex items-center space-x-4">
             <h1 className="font-bold text-lg tracking-tight hidden lg:block">Ctoguy <span className="text-studio-accent">Nano Pro</span></h1>
          </div>
          
          <ModeSelector />
          
          <div className="flex items-center space-x-2">
            {currentImage && (
              <>
                 <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setIsColorMode(true)}
                  icon={<Palette className="w-4 h-4" />}
                  title="Recolor Object"
                  className="hidden sm:flex"
                >
                  Color
                </Button>

                 <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setIsStyleMode(true)}
                  icon={<PaintBucket className="w-4 h-4" />}
                  title="Style Transfer"
                  className="hidden sm:flex"
                >
                  Style
                </Button>

                 <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setIsRemoveMode(true)}
                  icon={<Eraser className="w-4 h-4" />}
                  title="Remove Object"
                  className="hidden sm:flex"
                >
                  Remove
                </Button>
                 <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setIsRemoveMode(true)}
                  className="flex sm:hidden"
                >
                  <Eraser className="w-4 h-4" />
                </Button>

                <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setIsTransformMode(true)}
                  icon={<CropIcon className="w-4 h-4" />}
                  title="Transform / Crop"
                  className="hidden sm:flex"
                >
                  Transform
                </Button>
                <Button 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setIsTransformMode(true)}
                  className="flex sm:hidden"
                >
                  <CropIcon className="w-4 h-4" />
                </Button>

                <div className="h-6 w-px bg-studio-700 mx-2 hidden sm:block"></div>
                
                <Button 
                  variant="secondary" 
                  size="sm" 
                  onClick={handleUndo} 
                  disabled={history.length === 0}
                  icon={<Undo2 className="w-4 h-4" />}
                  title="Undo"
                />
                
                <Button 
                  variant="secondary" 
                  size="sm" 
                  onClick={handleRedo} 
                  disabled={future.length === 0}
                  icon={<Redo2 className="w-4 h-4" />}
                  title="Redo"
                />

                <Button 
                  variant="secondary" 
                  size="sm" 
                  onClick={handleDownload}
                  icon={<Download className="w-4 h-4" />}
                  className="hidden sm:flex"
                >
                   Export
                </Button>
              </>
            )}
            {!currentImage && mode !== EditorMode.GENERATE && (
                 <Button 
                 variant="ghost" 
                 size="sm" 
                 onClick={() => fileInputRef.current?.click()}
               >
                 Upload
               </Button>
            )}
          </div>
        </div>

        {/* Canvas / Workspace */}
        <div className="flex-1 relative bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-studio-950 overflow-hidden flex items-center justify-center p-4 md:p-6 lg:p-8">
          {isLoading && <LoadingOverlay message={mode === EditorMode.VIDEO ? "Rendering video animation (this takes a minute)..." : mode === EditorMode.ANALYZE ? "Analyzing image..." : isRemoveMode ? "Removing object..." : isColorMode ? "Recoloring object..." : isStyleMode ? "Applying artistic style..." : "Processing visuals..."} />}
          
          {isTransformMode && currentImage && (
            <ImageTransformer 
              imageUrl={currentImage} 
              onSave={handleTransformSave} 
              onCancel={() => setIsTransformMode(false)} 
            />
          )}

          {isRemoveMode && currentImage && (
            <MaskEditor 
              imageUrl={currentImage}
              onSave={handleRemoveSave}
              onCancel={() => setIsRemoveMode(false)}
            />
          )}

          {isColorMode && currentImage && (
             <ColorChangeTool
                imageUrl={currentImage}
                onCancel={() => setIsColorMode(false)}
                onSave={handleColorSave}
             />
          )}

          {isStyleMode && currentImage && (
             <StyleTransferTool
                imageUrl={currentImage}
                onCancel={() => setIsStyleMode(false)}
                onSave={handleStyleSave}
             />
          )}
          
          {!currentImage && mode !== EditorMode.GENERATE ? (
            <EmptyState />
          ) : (
            <div className="relative w-full h-full flex items-center justify-center">
               {mode === EditorMode.GENERATE && !currentImage && !isLoading && (
                   <div className="text-slate-500 text-center animate-pulse">
                       <Palette className="w-16 h-16 mx-auto mb-4 opacity-20" />
                       <p>Enter a prompt to start generating</p>
                   </div>
               )}
               
               {currentImage && !isTransformMode && !isRemoveMode && !isColorMode && !isStyleMode && (
                <div className="relative shadow-2xl shadow-black/50 border-4 border-studio-800 rounded-lg overflow-hidden max-w-full max-h-full flex flex-col justify-center group">
                    
                    {mode === EditorMode.VIDEO && currentVideo ? (
                        <video 
                            src={currentVideo} 
                            controls 
                            autoPlay 
                            loop 
                            className="max-w-full max-h-full"
                        />
                    ) : (
                        <img 
                            src={currentImage} 
                            alt="Editor content" 
                            className="max-w-full max-h-full object-contain"
                        />
                    )}
                    
                    {mode === EditorMode.VIDEO && !currentVideo && !isLoading && (
                        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6">
                            <Video className="w-16 h-16 text-studio-accent mb-4 animate-pulse" />
                            <h3 className="text-xl font-bold text-white">Ready to Animate</h3>
                            <p className="text-slate-300 max-w-sm mt-2 text-sm">
                                Enter a prompt below (e.g., "Cinematic pan, wind blowing in trees") and click Generate to animate this scene.
                            </p>
                        </div>
                    )}

                    {analysisResult && mode === EditorMode.ANALYZE && (
                        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm p-8 overflow-y-auto">
                            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                                <ScanEye className="w-6 h-6 mr-2 text-studio-accent" /> Analysis Result
                            </h3>
                            <p className="text-slate-200 leading-relaxed whitespace-pre-wrap font-mono text-sm">
                                {analysisResult}
                            </p>
                            <button 
                                onClick={() => setAnalysisResult(null)}
                                className="absolute top-4 right-4 text-slate-400 hover:text-white"
                            >
                                <XIcon className="w-6 h-6" />
                            </button>
                        </div>
                    )}
                </div>
               )}

                {error && (
                   <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-500/90 text-white px-4 py-2 rounded-full shadow-lg flex items-center backdrop-blur-md text-sm border border-red-400/50 z-50">
                    <AlertCircle className="w-4 h-4 mr-2" />
                    {error}
                  </div>
                )}
            </div>
          )}
        </div>

        {/* Bottom Prompt Bar */}
        <div className="h-auto min-h-[80px] bg-studio-900 border-t border-studio-700 p-4 px-4 md:px-6 z-20 flex flex-col gap-3 flex-shrink-0">
             {(mode === EditorMode.EDIT || mode === EditorMode.GENERATE) && (
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-thin no-scrollbar">
                        <div className="flex items-center text-xs text-studio-accent font-bold uppercase tracking-wider mr-2 flex-shrink-0">
                            <Camera className="w-3 h-3 mr-1" />
                            Inspiration:
                        </div>
                        {['Front view', '45 degree view', 'Birds eye view', 'Make surfacing area half as big', 'Center playground in the middle of surfacing area', 'Zoom out on scene', 'Zoom in on scene', 'Overhead view on scene'].map((p, i) => (
                            <button key={i} onClick={() => setPrompt(prev => prev + " " + p)} className="flex-shrink-0 text-xs bg-studio-800 border border-studio-700 hover:border-studio-accent rounded px-3 py-1 text-slate-400 hover:text-white transition-colors">{p}</button>
                        ))}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4 hidden sm:flex">
                        <Button variant="secondary" size="sm" onClick={handleProShot} icon={<Camera className="w-3 h-3"/>} title="Pro Shot (Single)">
                            Pro Shot
                        </Button>
                        <Button variant="secondary" size="sm" onClick={handleProShotGroup} icon={<Users className="w-3 h-3"/>} title="Pro Shot (Group)">
                            Pro Shot 2
                        </Button>
                         <Button variant="secondary" size="sm" onClick={handleCollageShot} icon={<LayoutGrid className="w-3 h-3"/>} title="Playground Collage">
                            Collage
                        </Button>
                         {history.length > 0 && (
                            <Button variant="secondary" size="sm" onClick={handleRegenerate} icon={<RefreshCw className="w-3 h-3"/>} title="Regenerate Last" />
                        )}
                    </div>
                </div>
             )}

            <div className="max-w-4xl w-full mx-auto relative">
              <div className="relative flex items-center space-x-2">
                <div className="relative flex-1">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-studio-accent">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <input
                      type="text"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleGenerate()}
                      placeholder={
                          mode === EditorMode.ANALYZE ? "Ask a question about the image (optional)..." :
                          mode === EditorMode.VIDEO ? "Describe the movement (e.g., 'Kids playing, trees swaying')..." :
                          mode === EditorMode.GENERATE ? "Describe the image you want to create..." : 
                          "Describe how you want to edit this image..."
                      }
                      className="w-full bg-studio-800 border border-studio-700 text-white placeholder-slate-500 rounded-xl py-3 md:py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-studio-accent focus:border-transparent shadow-lg text-sm md:text-base"
                      disabled={isLoading}
                    />
                </div>
                
                <div className="flex flex-col space-y-1">
                    <Button 
                        onClick={handleGenerate} 
                        disabled={isLoading || (mode !== EditorMode.ANALYZE && mode !== EditorMode.VIDEO && !prompt.trim())}
                        className="h-full px-4 md:px-6"
                        icon={mode === EditorMode.ANALYZE ? <ScanEye className="w-4 h-4"/> : mode === EditorMode.VIDEO ? <Video className="w-4 h-4"/> : <Wand2 className="w-4 h-4" />}
                    >
                        <span className="hidden md:inline">{mode === EditorMode.ANALYZE ? 'Analyze' : mode === EditorMode.VIDEO ? 'Animate' : 'Generate'}</span>
                    </Button>
                </div>
              </div>
            </div>
            
            {(mode === EditorMode.EDIT || mode === EditorMode.GENERATE) && (
                <div className="flex sm:hidden items-center justify-center space-x-2 pt-1">
                     <Button variant="secondary" size="sm" onClick={handleProShot} icon={<Camera className="w-3 h-3"/>}>
                        Pro
                    </Button>
                     <Button variant="secondary" size="sm" onClick={handleCollageShot} icon={<LayoutGrid className="w-3 h-3"/>}>
                        Collage
                    </Button>
                     {history.length > 0 && (
                        <Button variant="secondary" size="sm" onClick={handleRegenerate} icon={<RefreshCw className="w-3 h-3"/>} />
                    )}
                </div>
            )}
          </div>
      </div>
    </div>
  );
};

const XIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M18 6 6 18"/><path d="m6 6 18 18"/></svg>
);

const MaximizeIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>
);

export default App;
