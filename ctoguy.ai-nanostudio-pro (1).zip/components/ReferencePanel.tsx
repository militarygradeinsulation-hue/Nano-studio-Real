import React, { useRef } from 'react';
import { Plus, X } from 'lucide-react';
import { ReferenceImage } from '../types';

interface ReferencePanelProps {
  references: ReferenceImage[];
  onAdd: (urls: string[]) => void;
  onRemove: (id: string) => void;
}

const ReferencePanel: React.FC<ReferencePanelProps> = ({ references, onAdd, onRemove }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileArray = Array.from(files);
    const readPromises = fileArray.map(file => new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (ev) => resolve(ev.target?.result as string);
        // Explicitly cast file to Blob to resolve TS error where Array.from infers unknown
        reader.readAsDataURL(file as Blob);
    }));

    const results = await Promise.all(readPromises);
    onAdd(results);

    // Reset input
    e.target.value = '';
  };

  return (
    <div className="w-full">
      <p className="text-xs text-slate-400 mb-3">
        Upload images to help the model understand style, characters, or composition.
      </p>

      <div className="grid grid-cols-3 gap-2">
        {references.map((ref) => (
          <div key={ref.id} className="relative group aspect-square bg-studio-900 rounded border border-studio-700 overflow-hidden">
            <img src={ref.url} alt="Reference" className="w-full h-full object-cover" />
            <button 
              onClick={(e) => { e.stopPropagation(); onRemove(ref.id); }}
              className="absolute top-1 right-1 bg-black/70 hover:bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-all"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}

        {references.length < 10 && (
          <button 
            onClick={() => inputRef.current?.click()}
            className="aspect-square bg-studio-900/50 rounded border border-dashed border-studio-600 flex flex-col items-center justify-center hover:bg-studio-800 hover:border-studio-accent transition-all group"
          >
            <Plus className="w-5 h-5 text-slate-500 group-hover:text-studio-accent mb-1" />
            <span className="text-[10px] text-slate-500 group-hover:text-slate-300">Add</span>
          </button>
        )}
      </div>

      <input 
        type="file" 
        ref={inputRef} 
        className="hidden" 
        accept="image/*" 
        multiple
        onChange={handleFileChange}
      />
    </div>
  );
};

export default ReferencePanel;