import React from 'react';
import { Sparkles } from 'lucide-react';

interface LoadingOverlayProps {
  message?: string;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ message = "Processing pixels..." }) => {
  return (
    <div className="absolute inset-0 bg-studio-900/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
      <div className="relative">
        <div className="absolute inset-0 bg-studio-accent blur-xl opacity-20 animate-pulse-slow"></div>
        <Sparkles className="w-12 h-12 text-studio-accent animate-spin mb-4 relative z-10" style={{ animationDuration: '3s' }} />
      </div>
      <h3 className="text-xl font-medium text-white mb-2">AI Studio is working</h3>
      <p className="text-slate-400 text-sm animate-pulse">{message}</p>
    </div>
  );
};

export default LoadingOverlay;