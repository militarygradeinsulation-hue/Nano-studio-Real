import React, { useState, useRef, useEffect } from 'react';
import { Check, X, Move, Maximize, RotateCw, RotateCcw } from 'lucide-react';
import Button from './Button';

interface ImageTransformerProps {
  imageUrl: string;
  onSave: (newImage: string) => void;
  onCancel: () => void;
}

interface Rect {
  x: number; // Percentage 0-100
  y: number; // Percentage 0-100
  w: number; // Percentage 0-100
  h: number; // Percentage 0-100
}

const ImageTransformer: React.FC<ImageTransformerProps> = ({ imageUrl, onSave, onCancel }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const sourceImageRef = useRef<HTMLImageElement>(null);
  
  // State
  const [rotation, setRotation] = useState(0); // 0, 90, 180, 270
  const [crop, setCrop] = useState<Rect | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startPos, setStartPos] = useState<{x: number, y: number} | null>(null);
  
  // Resize target dimensions
  const [targetWidth, setTargetWidth] = useState<number>(0);
  const [targetHeight, setTargetHeight] = useState<number>(0);
  const [naturalSize, setNaturalSize] = useState<{w: number, h: number} | null>(null);

  // Initialize when image loads (hidden img element)
  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const { naturalWidth, naturalHeight } = e.currentTarget;
    setNaturalSize({ w: naturalWidth, h: naturalHeight });
    setTargetWidth(naturalWidth);
    setTargetHeight(naturalHeight);
    renderPreview(naturalWidth, naturalHeight, 0);
  };

  // Render the preview canvas whenever rotation or window size changes
  useEffect(() => {
    if (naturalSize) {
        renderPreview(naturalSize.w, naturalSize.h, rotation);
    }
  }, [rotation, naturalSize]);

  const renderPreview = (natW: number, natH: number, rot: number) => {
    const canvas = previewCanvasRef.current;
    const img = sourceImageRef.current;
    if (!canvas || !img) return;

    const isVertical = rot === 90 || rot === 270;
    const rotW = isVertical ? natH : natW;
    const rotH = isVertical ? natW : natH;

    // Calculate scale to fit in viewport (max 70vh height, 80vw width roughly)
    const maxWidth = Math.min(window.innerWidth * 0.8, 1200);
    const maxHeight = window.innerHeight * 0.65;
    
    const scale = Math.min(maxWidth / rotW, maxHeight / rotH, 1);
    
    const displayW = Math.round(rotW * scale);
    const displayH = Math.round(rotH * scale);

    canvas.width = displayW;
    canvas.height = displayH;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.clearRect(0, 0, displayW, displayH);

    // Draw Rotated
    ctx.save();
    ctx.translate(displayW / 2, displayH / 2);
    ctx.rotate((rot * Math.PI) / 180);
    ctx.scale(scale, scale);
    ctx.drawImage(img, -natW / 2, -natH / 2);
    ctx.restore();
  };

  const handleRotate = (direction: 'cw' | 'ccw') => {
    setRotation(prev => {
        const delta = direction === 'cw' ? 90 : -90;
        const next = (prev + delta + 360) % 360;
        return next;
    });
    
    // When rotating, reset crop as it no longer makes sense visually
    setCrop(null);
    
    // Swap target dimensions if we are rotating 90 degrees
    setTargetWidth(prevW => {
        setTargetHeight(prevH => prevW);
        return targetHeight;
    });
  };

  // Handle mouse events for drawing crop box
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    setStartPos({ x, y });
    setIsDragging(true);
    setCrop({ x, y, w: 0, h: 0 });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !startPos || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    let currentX = ((e.clientX - rect.left) / rect.width) * 100;
    let currentY = ((e.clientY - rect.top) / rect.height) * 100;
    
    // Clamp
    currentX = Math.max(0, Math.min(100, currentX));
    currentY = Math.max(0, Math.min(100, currentY));

    const w = Math.abs(currentX - startPos.x);
    const h = Math.abs(currentY - startPos.y);
    const x = Math.min(currentX, startPos.x);
    const y = Math.min(currentY, startPos.y);

    setCrop({ x, y, w, h });
    
    // Calculate the actual pixel dimensions of the crop selection
    // We need to know the dimensions of the "Rotated Surface"
    if (naturalSize) {
        const isVertical = rotation === 90 || rotation === 270;
        const rotW = isVertical ? naturalSize.h : naturalSize.w;
        const rotH = isVertical ? naturalSize.w : naturalSize.h;

        const cropPixelW = Math.round((rotW * w) / 100);
        const cropPixelH = Math.round((rotH * h) / 100);
        
        if (cropPixelW > 0 && cropPixelH > 0) {
            setTargetWidth(cropPixelW);
            setTargetHeight(cropPixelH);
        }
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleApply = () => {
    if (!naturalSize || !sourceImageRef.current) return;

    const isVertical = rotation === 90 || rotation === 270;
    const rotW = isVertical ? naturalSize.h : naturalSize.w;
    const rotH = isVertical ? naturalSize.w : naturalSize.h;

    // 1. Create temp canvas for full rotated image
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = rotW;
    tempCanvas.height = rotH;
    const tempCtx = tempCanvas.getContext('2d');
    if (!tempCtx) return;

    tempCtx.translate(rotW / 2, rotH / 2);
    tempCtx.rotate((rotation * Math.PI) / 180);
    tempCtx.drawImage(sourceImageRef.current, -naturalSize.w / 2, -naturalSize.h / 2);

    // 2. Determine source coordinates from the crop percentage
    let sx = 0, sy = 0, sw = rotW, sh = rotH;
    
    if (crop && crop.w > 0 && crop.h > 0) {
      sx = (crop.x / 100) * rotW;
      sy = (crop.y / 100) * rotH;
      sw = (crop.w / 100) * rotW;
      sh = (crop.h / 100) * rotH;
    }

    // 3. Draw to final canvas with resize
    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = targetWidth;
    finalCanvas.height = targetHeight;
    const finalCtx = finalCanvas.getContext('2d');
    
    if (!finalCtx) return;

    finalCtx.imageSmoothingEnabled = true;
    finalCtx.imageSmoothingQuality = 'high';

    finalCtx.drawImage(tempCanvas, sx, sy, sw, sh, 0, 0, targetWidth, targetHeight);
    
    // Preserve original mime type if possible, or default to png
    onSave(finalCanvas.toDataURL());
  };

  const clearCrop = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCrop(null);
    if (naturalSize) {
        // Reset target to full rotated size
        const isVertical = rotation === 90 || rotation === 270;
        setTargetWidth(isVertical ? naturalSize.h : naturalSize.w);
        setTargetHeight(isVertical ? naturalSize.w : naturalSize.h);
    }
  };

  return (
    <div className="absolute inset-0 bg-studio-900 z-40 flex flex-col">
      {/* Hidden Source Image */}
      <img 
        ref={sourceImageRef}
        src={imageUrl}
        onLoad={onImageLoad}
        className="hidden"
        alt="Hidden Source"
      />

      {/* Toolbar */}
      <div className="h-16 border-b border-studio-700 bg-studio-800 px-6 flex items-center justify-between flex-shrink-0">
        <h2 className="text-lg font-semibold flex items-center text-slate-200">
          <Maximize className="w-5 h-5 mr-2 text-studio-accent" /> 
          Transform
        </h2>
        
        <div className="flex items-center space-x-6">
            
            {/* Rotation Controls */}
            <div className="flex items-center space-x-1 border-r border-studio-700 pr-6">
                <Button variant="ghost" size="sm" onClick={() => handleRotate('ccw')} title="Rotate Left">
                    <RotateCcw className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleRotate('cw')} title="Rotate Right">
                    <RotateCw className="w-4 h-4" />
                </Button>
            </div>

            {/* Size Controls */}
            <div className="flex items-center space-x-2 text-sm">
                <span className="text-slate-400">Target:</span>
                <input 
                  type="number" 
                  value={targetWidth || ''}
                  onChange={(e) => setTargetWidth(Number(e.target.value))}
                  className="bg-studio-900 border border-studio-700 text-slate-200 rounded px-2 py-1 w-20 text-center focus:border-studio-accent outline-none"
                />
                <span className="text-slate-500">x</span>
                <input 
                  type="number" 
                  value={targetHeight || ''}
                  onChange={(e) => setTargetHeight(Number(e.target.value))}
                  className="bg-studio-900 border border-studio-700 text-slate-200 rounded px-2 py-1 w-20 text-center focus:border-studio-accent outline-none"
                />
                <span className="text-slate-500">px</span>
            </div>
            
            {/* Actions */}
            <div className="flex items-center space-x-2 pl-4 border-l border-studio-700">
                <Button variant="ghost" onClick={onCancel} icon={<X className="w-4 h-4" />}>Cancel</Button>
                <Button onClick={handleApply} icon={<Check className="w-4 h-4" />}>Apply</Button>
            </div>
        </div>
      </div>

      {/* Workspace */}
      <div className="flex-1 p-8 flex items-center justify-center bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-studio-950 overflow-hidden select-none">
        <div 
          ref={containerRef}
          className="relative shadow-2xl border border-studio-700 inline-block cursor-crosshair bg-black/20 backdrop-blur-sm"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* Display Canvas */}
          <canvas 
            ref={previewCanvasRef}
            className="block pointer-events-none"
          />
          
          {/* Overlay Background for Crop (Darkens outside area) */}
          <div className="absolute inset-0 pointer-events-none">
             {crop && crop.w > 0 && (
               <>
                  <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: `${crop.y}%`, background: 'rgba(0,0,0,0.6)' }}></div>
                  <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: `${100 - (crop.y + crop.h)}%`, background: 'rgba(0,0,0,0.6)' }}></div>
                  <div style={{ position: 'absolute', top: `${crop.y}%`, left: 0, width: `${crop.x}%`, height: `${crop.h}%`, background: 'rgba(0,0,0,0.6)' }}></div>
                  <div style={{ position: 'absolute', top: `${crop.y}%`, right: 0, width: `${100 - (crop.x + crop.w)}%`, height: `${crop.h}%`, background: 'rgba(0,0,0,0.6)' }}></div>
               </>
             )}
          </div>

          {/* Selection Box */}
          {crop && crop.w > 0 && (
            <div 
              className="absolute border border-white shadow-[0_0_0_1px_rgba(0,0,0,0.5)] z-10"
              style={{
                left: `${crop.x}%`,
                top: `${crop.y}%`,
                width: `${crop.w}%`,
                height: `${crop.h}%`,
              }}
            >
              {/* Handles */}
              <div className="absolute -top-1 -left-1 w-2 h-2 bg-white border border-black"></div>
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-white border border-black"></div>
              <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-white border border-black"></div>
              <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-white border border-black"></div>
              
              {/* Info Label */}
              <div className="absolute -top-9 left-0 bg-studio-900 text-white text-xs px-2 py-1 rounded shadow border border-studio-700 whitespace-nowrap pointer-events-auto flex items-center gap-2">
                <span>{targetWidth} x {targetHeight}</span>
                <button onClick={clearCrop} className="hover:text-red-400 p-0.5"><X className="w-3 h-3"/></button>
              </div>
              
              {/* Grid Lines (Rule of Thirds) */}
              <div className="absolute left-1/3 top-0 bottom-0 w-px bg-white/30"></div>
              <div className="absolute left-2/3 top-0 bottom-0 w-px bg-white/30"></div>
              <div className="absolute top-1/3 left-0 right-0 h-px bg-white/30"></div>
              <div className="absolute top-2/3 left-0 right-0 h-px bg-white/30"></div>
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-studio-900 text-slate-500 text-center text-xs py-2 border-t border-studio-800">
        Click and drag to crop. Use rotation buttons to reorient. Adjust dimensions to resize.
      </div>
    </div>
  );
};

export default ImageTransformer;