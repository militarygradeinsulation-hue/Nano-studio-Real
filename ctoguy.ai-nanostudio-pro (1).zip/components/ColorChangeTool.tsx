import React, { useRef, useState } from 'react';
import { Palette, Check, X, Undo2, RotateCcw, Type, Settings2 } from 'lucide-react';
import Button from './Button';

interface ColorChangeToolProps {
  imageUrl: string;
  onSave: (maskImage: string, targetColor: string, prompt: string) => void;
  onCancel: () => void;
}

const ColorChangeTool: React.FC<ColorChangeToolProps> = ({ imageUrl, onSave, onCancel }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushSize, setBrushSize] = useState(60); // Larger default for easier area selection
  const [targetColor, setTargetColor] = useState('#3b82f6'); // Default Blue
  const [prompt, setPrompt] = useState('');
  const [strokeHistory, setStrokeHistory] = useState<ImageData[]>([]);
  
  // Advanced Settings
  const [showSettings, setShowSettings] = useState(false);
  const [intensity, setIntensity] = useState(100); // 0 - 100%
  const [saturation, setSaturation] = useState(100); // 0 - 200% (100 is normal)
  const [brightness, setBrightness] = useState(100); // 0 - 200% (100 is normal)

  const initCanvas = () => {
    const canvas = canvasRef.current;
    const img = imageRef.current;
    const container = containerRef.current;
    
    if (!canvas || !img || !container) return;

    const maxWidth = container.clientWidth;
    const maxHeight = container.clientHeight;
    
    const scale = Math.min(maxWidth / img.naturalWidth, maxHeight / img.naturalHeight);
    
    const displayWidth = img.naturalWidth * scale;
    const displayHeight = img.naturalHeight * scale;

    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    
    canvas.style.width = `${displayWidth}px`;
    canvas.style.height = `${displayHeight}px`;
    img.style.width = `${displayWidth}px`;
    img.style.height = `${displayHeight}px`;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setStrokeHistory(prev => [...prev, imageData]);

    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) ctx.beginPath();
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    ctx.lineWidth = brushSize;
    // Use Blue for visual indication of Color tool (vs Red for Remove)
    ctx.strokeStyle = 'rgba(60, 130, 246, 0.8)'; 
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const handleUndo = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || strokeHistory.length === 0) return;

    const lastState = strokeHistory[strokeHistory.length - 1];
    ctx.putImageData(lastState, 0, 0);
    setStrokeHistory(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setStrokeHistory(prev => [...prev, imageData]);
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handleApply = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const finalCanvas = document.createElement('canvas');
    finalCanvas.width = canvas.width;
    finalCanvas.height = canvas.height;
    const finalCtx = finalCanvas.getContext('2d');
    if (!finalCtx) return;
    
    finalCtx.fillStyle = 'black';
    finalCtx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);
    finalCtx.drawImage(canvas, 0, 0);
    
    const imgData = finalCtx.getImageData(0, 0, finalCanvas.width, finalCanvas.height);
    const data = imgData.data;
    
    for(let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i+1];
        const b = data[i+2];
        
        if (r > 0 || g > 0 || b > 0) {
            data[i] = 255;
            data[i+1] = 255;
            data[i+2] = 255;
            data[i+3] = 255;
        } else {
            data[i] = 0;
            data[i+1] = 0;
            data[i+2] = 0;
            data[i+3] = 255;
        }
    }
    finalCtx.putImageData(imgData, 0, 0);

    // Construct advanced prompt
    let fullPrompt = prompt;
    const mods = [];
    if (intensity !== 100) mods.push(`Blend Intensity: ${intensity}%`);
    if (saturation !== 100) mods.push(`Saturation: ${saturation}%`);
    if (brightness !== 100) mods.push(`Brightness: ${brightness}%`);
    
    if (mods.length > 0) {
        fullPrompt += ` [Modifications: ${mods.join(', ')}]`;
    }

    onSave(finalCanvas.toDataURL('image/png'), targetColor, fullPrompt);
  };

  const Slider = ({ label, value, min, max, onChange, format = (v: number) => `${v}%` }: any) => (
    <div className="flex items-center space-x-3 text-xs">
        <span className="w-16 text-slate-400">{label}</span>
        <input 
            type="range" 
            min={min} 
            max={max} 
            value={value} 
            onChange={(e) => onChange(Number(e.target.value))}
            className="flex-1 accent-studio-accent h-1.5 bg-studio-700 rounded-lg appearance-none cursor-pointer"
        />
        <span className="w-10 text-right text-slate-300 font-mono">{format(value)}</span>
    </div>
  );

  return (
    <div className="absolute inset-0 bg-studio-900 z-40 flex flex-col">
      {/* Header */}
      <div className="h-16 border-b border-studio-700 bg-studio-800 px-4 md:px-6 flex items-center justify-between flex-shrink-0 gap-4 relative z-50">
        <h2 className="text-lg font-semibold flex items-center text-slate-200 whitespace-nowrap">
          <Palette className="w-5 h-5 mr-2 text-studio-accent" /> 
          <span className="hidden sm:inline">Recolor Object</span>
        </h2>
        
        {/* Controls Row */}
        <div className="flex-1 flex items-center justify-center space-x-3">
             {/* Color Picker */}
             <div className="flex items-center space-x-2 bg-studio-900 rounded-lg p-1 border border-studio-700">
                <input 
                    type="color" 
                    value={targetColor}
                    onChange={(e) => setTargetColor(e.target.value)}
                    className="w-8 h-8 rounded cursor-pointer bg-transparent border-0 p-0"
                    title="Choose Target Color"
                />
                <span className="text-xs font-mono text-slate-300 hidden md:inline">{targetColor}</span>
             </div>

             {/* Description Input */}
             <div className="hidden md:flex relative w-full max-w-xs">
                <Type className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input 
                    type="text" 
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe object (optional)..."
                    className="w-full bg-studio-900 border border-studio-700 rounded-lg py-1.5 pl-9 pr-3 text-sm text-white placeholder-slate-500 focus:ring-1 focus:ring-studio-accent outline-none"
                />
            </div>

            {/* Advanced Toggle */}
            <Button 
                variant={showSettings ? "primary" : "ghost"} 
                size="sm" 
                onClick={() => setShowSettings(!showSettings)}
                title="Fine Tuning"
                className="hidden sm:flex"
            >
                <Settings2 className="w-4 h-4" />
            </Button>
        </div>

        <div className="flex items-center space-x-2">
            <div className="flex items-center bg-studio-900 rounded-lg p-0.5 border border-studio-700">
                <Button variant="ghost" size="sm" onClick={handleUndo} disabled={strokeHistory.length === 0} title="Undo">
                    <Undo2 className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={handleClear} title="Clear">
                    <RotateCcw className="w-4 h-4" />
                </Button>
            </div>

            <Button variant="ghost" onClick={onCancel} icon={<X className="w-4 h-4" />}>
                <span className="hidden sm:inline">Cancel</span>
            </Button>
            <Button onClick={handleApply} icon={<Check className="w-4 h-4" />}>
                <span className="hidden sm:inline">Apply</span>
                <span className="sm:hidden">Done</span>
            </Button>
        </div>
      </div>

      {/* Advanced Settings Panel */}
      {showSettings && (
          <div className="absolute top-16 left-0 right-0 bg-studio-800/95 backdrop-blur-md border-b border-studio-700 p-4 z-40 animate-in slide-in-from-top-2">
              <div className="max-w-2xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Slider 
                    label="Intensity" 
                    value={intensity} 
                    min={0} 
                    max={100} 
                    onChange={setIntensity} 
                  />
                  <Slider 
                    label="Saturation" 
                    value={saturation} 
                    min={0} 
                    max={200} 
                    onChange={setSaturation} 
                  />
                  <Slider 
                    label="Brightness" 
                    value={brightness} 
                    min={0} 
                    max={200} 
                    onChange={setBrightness} 
                  />
              </div>
          </div>
      )}
      
      {/* Mobile Prompt & Settings Toggle */}
      <div className="md:hidden px-4 py-2 bg-studio-800 border-b border-studio-700 flex gap-2">
          <input 
            type="text" 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe object..."
            className="flex-1 bg-studio-900 border border-studio-700 rounded-lg py-2 px-3 text-sm text-white placeholder-slate-500 outline-none"
        />
        <Button variant={showSettings ? "primary" : "secondary"} size="icon" onClick={() => setShowSettings(!showSettings)}>
            <Settings2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Workspace */}
      <div className="flex-1 p-4 md:p-8 flex items-center justify-center bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-studio-950 overflow-hidden select-none relative">
        <div ref={containerRef} className="relative max-w-full max-h-full flex items-center justify-center">
            <img 
                ref={imageRef} 
                src={imageUrl} 
                alt="Source" 
                className="max-w-full max-h-full object-contain block pointer-events-none select-none"
                onLoad={initCanvas}
            />
            <canvas 
                ref={canvasRef}
                className="absolute top-0 left-0 touch-none cursor-crosshair"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
            />
        </div>
      </div>
      
      <div className="bg-studio-900 text-slate-500 text-center text-xs py-2 border-t border-studio-800">
        Click or paint to select the area. Use settings for detailed hue/saturation shifts.
      </div>
    </div>
  );
};

export default ColorChangeTool;